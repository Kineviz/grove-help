These dog photos are from https://dog.ceo/dog-api/.

Filename	Breed
n02085936_2905.jpg	Maltese
n02099267_1118.jpg	Flatcoated retriever
n02090721_5759.jpg	Irish wolfhound
n02099601_286.jpg	Golden retriever
n02105855_4048.jpg	Shetland sheepdog
n02115641_10604.jpg	Dingo
n02104029_4557.jpg	Kuvasz
n02113712_109.jpg	Miniature poodle
n02099849_1115.jpg	Chesapeake retriever
n02105056_6790.jpg	Groenendael
n02102177_1257.jpg	Welsh spaniel
n02113186_13256.jpg	Cardigan Welsh corgi
